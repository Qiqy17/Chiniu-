/**
 * Created by mac on 2021/7/11.
 */
var item={
    img:'static00/img/cute.png', //图片
    info:'你好呀~~欢迎来到池牛！！！', //文字
    href:'http://localhost:63342/chiniu/index.html', //链接
    close:false, //显示关闭按钮
    speed:8, //延迟,单位秒,默认6
    color:'#bd0000', //颜色,默认白色
    old_ie_color:'#bd0000', //ie低版兼容色,不能与网页背景相同,默认黑色
}
$('body').barrager(item);